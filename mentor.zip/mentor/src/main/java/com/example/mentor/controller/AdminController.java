package com.example.mentor.controller;

import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.mentor.dao.MentorDao;
import com.example.mentor.dao.SendProposalDao;
import com.example.mentor.dao.SkillDao;
import com.example.mentor.dao.UserDao;
import com.example.mentor.model.Mentor;
import com.example.mentor.model.Skills;
import com.example.mentor.model.Userdb;
@Transactional
@Controller
public class AdminController {

	@Autowired
	MentorDao mentorDao;

	@Autowired
	UserDao userDao;
	@Autowired
	SendProposalDao sendDao;
@Autowired
 SkillDao skillDao;
	@RequestMapping(path = "/blockStatus")
	public String blockStatus(@RequestParam("id") int id) {

		ModelAndView mav = new ModelAndView();

		Userdb user = userDao.findByid(id);

		if (user.getBlock().equals("Block")) {
			user.setBlock("UnBlock");
		} else {
			user.setBlock("Block");
		}

		userDao.save(user);

		return "redirect:/allUserList";
	}

	@RequestMapping(path = "/blockStatusMentor")
	public String blockStatusMentor(@RequestParam("id") int id) {

		ModelAndView mav = new ModelAndView();

		Mentor user = mentorDao.findBymentorId(id);

		if (user.getBlock().equals("Block")) {
			user.setBlock("UnBlock");
		} else {
			user.setBlock("Block");
		}

		mentorDao.save(user);

		return "redirect:/mentorList";
	}
	
	@RequestMapping(path = "/addTechnology", method = RequestMethod.GET)
	public String addTechnology(Model model) {
		Skills skill = new Skills();
		model.addAttribute("skill", skill);
		return "addTechnology";

	}
	@RequestMapping(path = "/addTechnology1", method = RequestMethod.POST)
	public String addTechnology1(@ModelAttribute("skill") Skills skill) {
		
		skillDao.save(skill);
		return "redirect:/skillList";

	}
	
	@RequestMapping(path = "/skillList")
	public ModelAndView skillList(HttpSession session) throws Exception {
		ModelAndView mv = new ModelAndView();

		mv.setViewName("skillList");
		
		mv.addObject("skillList", skillDao.findAll());
		session.setAttribute("skillList", skillDao.findAll());
		return mv;
	}
	
	@RequestMapping(path="deleteSkill")
	public ModelAndView deleteSkill(@RequestParam("id") int id){
		ModelAndView mv = new ModelAndView();
		System.out.println(id);
		skillDao.deleteByskillId(id);
		mv=new ModelAndView("redirect:/skillList");
		return mv;
	}

}
