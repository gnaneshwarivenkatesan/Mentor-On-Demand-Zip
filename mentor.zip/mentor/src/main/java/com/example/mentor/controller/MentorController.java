package com.example.mentor.controller;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.mentor.dao.MentorDao;
import com.example.mentor.dao.SendProposalDao;
import com.example.mentor.dao.SkillDao;
import com.example.mentor.dao.UserDao;
import com.example.mentor.model.Mentor;
import com.example.mentor.model.SendProposal;
import com.example.mentor.model.Userdb;

@Controller
public class MentorController {

	@Autowired
	MentorDao mentorDao;

	@Autowired
	UserDao userDao;
	@Autowired
	SendProposalDao sendDao;
	@Autowired
	SkillDao skillDao;

	@RequestMapping(path = "/mentorRegister", method = RequestMethod.GET)
	public String register(Model model) {
		Mentor mentor = new Mentor();
		model.addAttribute("mentor", mentor);
		model.addAttribute("skillList", skillDao.findAll());
		return "mentorRegistration";

	}

	@RequestMapping(path = "/mentorRegister", method = RequestMethod.POST)
	public ModelAndView register(@Valid @ModelAttribute("mentor") Mentor mentor, BindingResult result)
			throws Exception {
		ModelAndView mav = null;
		
		mentorDao.save(mentor);
		mav = new ModelAndView("redirect:/mentorlogin");
		return mav;
	}

	@RequestMapping(path = "/mentorlogin", method = RequestMethod.GET)
	public String login(Model model) {
		Mentor mentor = new Mentor();
		model.addAttribute("mentor", mentor);
		return "login";
	}

	@RequestMapping(path = "/mentorlogin", method = RequestMethod.POST)
	public ModelAndView login1(Mentor mentor, Model model, HttpSession session) throws Exception {

		ModelAndView mav = null;

		String email = mentor.getEmail();

		List<Mentor> user1 = mentorDao.findByemail(email);
		System.out.println(user1);
		if (user1.isEmpty()) {
			mav = new ModelAndView("login", "message", "Invalid Username or Password");
		} else {
			Mentor user2 = user1.get(0);
			if (user2.getBlock().equals("UnBlock")) {
				mav = new ModelAndView("login", "message", "Mentor is Blocked You can't Login");
			} else {
				if ((mentor.getEmail().equals(user2.getEmail()))
						&& (mentor.getPassword().equals(user2.getPassword()))) {

					session.setAttribute("mentor", user2);
					mav = new ModelAndView("redirect:/userList");
				} else {

					mav = new ModelAndView("login", "message", "Invalid Username or Password");
				}
			}
		}
		return mav;

	}

	@RequestMapping(path = "/searchMentor", method = RequestMethod.GET)
	public String searchMentor(ModelMap model) {
		Mentor mentor = new Mentor();
		model.addAttribute("search", mentor);
		model.addAttribute("skillList", skillDao.findAll());
		return "searchMentor";
	}

	@RequestMapping(path = "/searchMentor1", method = RequestMethod.POST)
	public ModelAndView searchMentor1(Mentor mentor) {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("technologyList");

		mav.addObject("technologyList", mentorDao.findBytechnology(mentor.getTechnology()));
		return mav;
	}

	@RequestMapping(path = "/mentorList")
	public ModelAndView getMentorList() throws Exception {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("mentorList");
		mv.addObject("skillList", mentorDao.findAll());
		return mv;
	}
	@RequestMapping(path = "/mentorList1")
	public ModelAndView getMentorList1() throws Exception {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("mentorList1");
		mv.addObject("technologyList1", mentorDao.findAll());
		return mv;
	}

	@RequestMapping(path = "/updateStatus")
	public ModelAndView updateStatus(@RequestParam("id") int id, @RequestParam("userId") int userId, Mentor mentor) {
		ModelAndView mav = new ModelAndView();
		Mentor mentor1 = mentorDao.findBymentorId(id);

		Userdb user = userDao.findByid(userId);

		user.setBlockStatus("RequestPending");
		mentor1.setStatus("RequestSent");

		SendProposal s = new SendProposal();
		s.setMentorId(id);
		s.setUser(user);
		s.setStatus("1");
		sendDao.save(s);
		mentorDao.save(mentor1);
		userDao.save(user);
		mav = new ModelAndView("redirect:/mentorList1");
		return mav;
	}

}
