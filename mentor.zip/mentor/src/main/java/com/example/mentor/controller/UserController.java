package com.example.mentor.controller;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.mentor.dao.MentorDao;
import com.example.mentor.dao.SendProposalDao;
import com.example.mentor.dao.SkillDao;
import com.example.mentor.dao.UserDao;
import com.example.mentor.model.Mentor;
import com.example.mentor.model.SendProposal;
import com.example.mentor.model.Userdb;
import com.example.mentor.service.UserService;

@Controller
public class UserController {
	@Autowired
	private UserService userService;

	@Autowired
	private UserDao userDao;

	@Autowired
	private MentorDao mentorDao;
	@Autowired
	private SendProposalDao sendDao;
	@Autowired
	SkillDao skillDao;

	@RequestMapping(path = "/comparison", method = RequestMethod.GET)
	public String ipo(Model model) {

		return "ComparisonPage";

	}

	@RequestMapping(path = "/register", method = RequestMethod.GET)
	public String register(Model model) {
		Userdb user = new Userdb();
		model.addAttribute("user", user);
		return "registration";

	}

	@RequestMapping(path = "/register", method = RequestMethod.POST)
	public String register(@Valid @ModelAttribute("user") Userdb user, BindingResult result) throws Exception {
		if (result.hasErrors())

		{
			return "registration";
		}

		userService.register(user);
		return "redirect:/login";
	}

	@RequestMapping(path = "/login", method = RequestMethod.GET)
	public String login(Model model) {
		Userdb user1 = new Userdb();
		Mentor mentor = new Mentor();
		model.addAttribute("search", mentor);
		model.addAttribute("user", user1);
		model.addAttribute("skillList", skillDao.findAll());
		return "userLogin";
	}

	@RequestMapping(path = "/login", method = RequestMethod.POST)
	public ModelAndView login1(Userdb user, Model model, HttpSession session) throws Exception {

		ModelAndView mav = null;

		String email = user.getEmail();

		List<Userdb> user1 = userService.findByemail(email);
		System.out.println(user1);
		if (user1.isEmpty()) {
			mav = new ModelAndView("login", "message", "Invalid Username or Password");
		} else {
			Userdb user2 = user1.get(0);
			if (user2.getBlock().equals("UnBlock")) {
				mav = new ModelAndView("userLogin", "message", "User is Blocked You can't Login");
			} else {
				if ((user.getEmail().equals(user2.getEmail())) && (user.getPassword().equals(user2.getPassword()))) {

					if (user2.getUserType().equals("Admin")) {
						mav = new ModelAndView("admin");
					} else {
						session.setAttribute("user", user2);
						mav = new ModelAndView("redirect:/searchMentor");
					}

				} else {

					mav = new ModelAndView("userLogin", "message", "Invalid Username or Password");
				}
			}
		}

		return mav;

	}

	@RequestMapping(path = "/userList")
	public ModelAndView getuserList(HttpSession session) throws Exception {
		ModelAndView mv = new ModelAndView();
		Mentor mentor = (Mentor) session.getAttribute("mentor");

		int id = mentor.getMentorId();
		sendDao.findAll();
		mv.setViewName("userList");
		mv.addObject("userList", sendDao.findAll());
		mv.addObject("userList1", userDao.findAll());
		System.out.println(userDao.findAll());
		return mv;
	}

	@RequestMapping(path = "/allUserList")
	public ModelAndView allUserList() throws Exception {
		ModelAndView mv = new ModelAndView();

		mv.setViewName("allUserList");
		mv.addObject("userList1", userDao.findAll());
		return mv;
	}

	@RequestMapping(path = "/confirmStatus")
	public ModelAndView updateStatus(@RequestParam("id") int id, @RequestParam("userId") int userId, Mentor mentor) {
		ModelAndView mav = new ModelAndView();

		Mentor mentor1 = mentorDao.findBymentorId(id);
		Userdb user = userDao.findByid(userId);
		SendProposal s = new SendProposal();
		s.setStatus("1");

		user.setBlockStatus("Approved");
		mentor1.setStatus("Approved");

		mentorDao.save(mentor1);
		userDao.save(user);

		mav = new ModelAndView("redirect:/userList");
		return mav;
	}

}
