package com.example.mentor.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.mentor.model.Mentor;
import com.example.mentor.model.Userdb;

@Repository
public interface MentorDao extends JpaRepository<Mentor, Integer> {

	
	
	@Query("select m from Mentor m where m.technology like %:technology%")
	public List<Mentor> findBytechnology(@Param(value = "technology") String technology);

	public Mentor findBymentorId(int id);

	public List<Mentor> findByemail(String email);

}
