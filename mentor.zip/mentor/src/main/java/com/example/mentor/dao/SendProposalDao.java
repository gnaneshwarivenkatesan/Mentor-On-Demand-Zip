package com.example.mentor.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.mentor.model.SendProposal;
import com.example.mentor.model.Userdb;

public interface SendProposalDao extends JpaRepository<SendProposal, Integer> {

}
