package com.example.mentor.dao;

import org.springframework.data.jpa.repository.JpaRepository;


import com.example.mentor.model.Skills;

public interface SkillDao extends JpaRepository<Skills, Integer>{

	public int deleteByskillId(int id);
	
}
