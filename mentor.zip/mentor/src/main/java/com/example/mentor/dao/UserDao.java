package com.example.mentor.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.mentor.model.Userdb;

public interface UserDao extends JpaRepository<Userdb, Integer> {

	List<Userdb> findByemail(String email);

	Userdb findByid(int userId);

	

}
