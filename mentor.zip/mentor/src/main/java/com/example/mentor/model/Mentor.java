package com.example.mentor.model;



import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Mentor {

	@Id
	@Column(name = "mentorId")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int mentorId;
	@Column(name = "name")
	private String name;

	@Column(name = "email")
	private String email;
	@Column(name = "password")
	private String password;
	@Column(name = "address")
	private String address;
	@Column(name = "linkedin_url")
	private String linkedinUrl;
	@Column(name = "technology")
	private String technology;
	@Column(name = "experience")
	private int experience;
	@Column(name = "contact_number")
	private String contactNumber;

	@Column(name = "trainings_completed")
	private int trainingsCompleted;

	@Column(name = "from_date")
	private Date fromDate;
	@Column(name = "to_date")
	private Date toDate;
	@Column(name = "from_time")
	private String fromTime;
	@Column(name = "to_time")
	private String toTime;

	@Column(name = "status")
	private String status;

	@Column(name = "block")
	private String block;

	public String getBlock() {
		return block;
	}

	public void setBlock(String block) {
		this.block = block;
	}

	public int getMentorId() {
		return mentorId;
	}

	public void setMentorId(int mentorId) {
		this.mentorId = mentorId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getLinkedinUrl() {
		return linkedinUrl;
	}

	public void setLinkedinUrl(String linkedinUrl) {
		this.linkedinUrl = linkedinUrl;
	}

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	public int getTrainingsCompleted() {
		return trainingsCompleted;
	}

	public void setTrainingsCompleted(int trainingsCompleted) {
		this.trainingsCompleted = trainingsCompleted;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public String getFromTime() {
		return fromTime;
	}

	public void setFromTime(String fromTime) {
		this.fromTime = fromTime;
	}

	public String getToTime() {
		return toTime;
	}

	public void setToTime(String toTime) {
		this.toTime = toTime;
	}

	@Override
	public String toString() {
		return "Mentor [mentorId=" + mentorId + ", name=" + name + ", email=" + email + ", password=" + password
				+ ", address=" + address + ", linkedinUrl=" + linkedinUrl + ", technology=" + technology
				+ ", experience=" + experience + ", contactNumber=" + contactNumber + ", trainingsCompleted="
				+ trainingsCompleted + ", fromDate=" + fromDate + ", toDate=" + toDate + ", fromTime=" + fromTime
				+ ", toTime=" + toTime + ", status=" + status + "]";
	}

}
