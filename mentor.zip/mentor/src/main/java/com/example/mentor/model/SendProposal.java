package com.example.mentor.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "send_proposal")
public class SendProposal {
	@Id
	@Column(name = "id")

	private int id;
	@Column
	private int mentorId;
	private String status;
	
	@ManyToOne(cascade = CascadeType.REFRESH)

	@JoinColumn(name = "userId")
	private Userdb user;

	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getMentorId() {
		return mentorId;
	}

	public void setMentorId(int mentorId) {
		this.mentorId = mentorId;
	}

	
	public Userdb getUser() {
		return user;
	}

	public void setUser(Userdb user) {
		this.user = user;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
