package com.example.mentor.service;

import java.util.List;
import java.util.Optional;

import com.example.mentor.model.Userdb;

public interface UserService {

	public Userdb register(Userdb user) throws Exception;

	public Optional<Userdb> login(Integer id);

	public List<Userdb> findByemail(String email);

}
