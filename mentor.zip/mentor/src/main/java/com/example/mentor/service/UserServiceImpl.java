package com.example.mentor.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.mentor.dao.UserDao;
import com.example.mentor.model.Userdb;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	UserDao userDao;

	@Override
	public Userdb register(Userdb user) throws Exception {
		return userDao.save(user);

	}

	public Optional<Userdb> login(Integer id) {
		// TODO Auto-generated method stub
		return userDao.findById(id);
	}

	@Override
	public List<Userdb> findByemail(String email) {
		// TODO Auto-generated method stub
		return userDao.findByemail(email);
	}

}
